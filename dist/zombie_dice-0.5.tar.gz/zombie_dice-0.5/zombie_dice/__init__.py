from .zombie_dice import Zombiedice
